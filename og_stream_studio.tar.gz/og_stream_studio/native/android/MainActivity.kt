package com.ogstudio.og_stream_studio

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "og_stream_studio/stream"
    private val requestCapture = 4242
    private var pending: Map<*, *>? = null
    private var channel: MethodChannel? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
        channel = ch
        StreamService.statusListener = { s -> ch.invokeMethod("status", s) }

        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> {
                    pending = call.arguments as? Map<*, *>
                    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    @Suppress("DEPRECATION")
                    startActivityForResult(mpm.createScreenCaptureIntent(), requestCapture)
                    result.success(true)
                }
                "stop" -> {
                    startService(Intent(this, StreamService::class.java).setAction(StreamService.ACTION_STOP))
                    result.success(true)
                }
                "overlay" -> {
                    val bytes = call.arguments as? ByteArray
                    if (bytes != null) {
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) StreamService.setOverlay(bmp)
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCapture) return
        val args = pending
        pending = null
        if (resultCode != RESULT_OK || data == null || args == null) {
            StreamService.notifyStatus("failed: screen capture permission denied")
            return
        }
        val intent = Intent(this, StreamService::class.java).apply {
            action = StreamService.ACTION_START
            putExtra("url", args["url"] as? String)
            putExtra("width", (args["width"] as? Number)?.toInt() ?: 720)
            putExtra("height", (args["height"] as? Number)?.toInt() ?: 1280)
            putExtra("fps", (args["fps"] as? Number)?.toInt() ?: 30)
            putExtra("bitrate", (args["bitrate"] as? Number)?.toInt() ?: 3_000_000)
            putExtra("resultCode", resultCode)
            putExtra("data", data)
        }
        ContextCompat.startForegroundService(this, intent)
    }
}
