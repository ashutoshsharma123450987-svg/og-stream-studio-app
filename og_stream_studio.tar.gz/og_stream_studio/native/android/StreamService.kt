package com.ogstudio.og_stream_studio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.library.rtmp.RtmpDisplay

/**
 * Foreground service that owns the MediaProjection screen capture and the RTMP
 * encoder (RootEncoder). Flutter sends a transparent PNG overlay (chat, text,
 * images) which is composited over the captured screen.
 */
class StreamService : Service() {

    companion object {
        const val ACTION_START = "com.ogstudio.og_stream_studio.START"
        const val ACTION_STOP = "com.ogstudio.og_stream_studio.STOP"
        private const val CHANNEL_ID = "og_stream_studio_live"
        private const val NOTIF_ID = 4201

        @Volatile
        var display: RtmpDisplay? = null
        var statusListener: ((String) -> Unit)? = null

        private var overlayFilter: ImageObjectFilterRender? = null
        private val main = Handler(Looper.getMainLooper())

        fun notifyStatus(s: String) {
            main.post { statusListener?.invoke(s) }
        }

        fun setOverlay(bmp: Bitmap) {
            main.post {
                val d = display ?: return@post
                if (!d.isStreaming) return@post
                try {
                    var f = overlayFilter
                    if (f == null) {
                        f = ImageObjectFilterRender()
                        d.glInterface.setFilter(f)
                        f.setScale(100f, 100f)
                        f.setPosition(0f, 0f)
                        overlayFilter = f
                    }
                    f.setImage(bmp)
                } catch (e: Exception) {
                    notifyStatus("failed: overlay error ${e.message}")
                }
            }
        }
    }

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {
            notifyStatus("connecting")
        }

        override fun onConnectionSuccess() {
            notifyStatus("live")
        }

        override fun onConnectionFailed(reason: String) {
            notifyStatus("failed: $reason")
            stopEverything(reportStopped = false)
        }

        override fun onNewBitrate(bitrate: Long) {}

        override fun onDisconnect() {
            notifyStatus("stopped")
        }

        override fun onAuthError() {
            notifyStatus("failed: authentication error (check stream key)")
        }

        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startStreaming(intent)
            ACTION_STOP -> stopEverything(reportStopped = true)
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startStreaming(intent: Intent) {
        goForeground()
        val url = intent.getStringExtra("url") ?: return fail("missing url")
        val width = intent.getIntExtra("width", 720)
        val height = intent.getIntExtra("height", 1280)
        val fps = intent.getIntExtra("fps", 30)
        val bitrate = intent.getIntExtra("bitrate", 3_000_000)
        val resultCode = intent.getIntExtra("resultCode", 0)
        val data: Intent = intent.getParcelableExtra("data") ?: return fail("no screen permission")

        try {
            val d = RtmpDisplay(applicationContext, true, checker)
            d.setIntentResult(resultCode, data)
            val dpi = resources.displayMetrics.densityDpi
            val ok = d.prepareVideo(width, height, fps, bitrate, 0, dpi) && d.prepareAudio()
            if (!ok) return fail("encoder not supported on this device")
            display = d
            overlayFilter = null
            d.startStream(url)
        } catch (e: Exception) {
            fail(e.message ?: "unknown error")
        }
    }

    private fun fail(reason: String) {
        notifyStatus("failed: $reason")
        stopEverything(reportStopped = false)
    }

    private fun stopEverything(reportStopped: Boolean) {
        try {
            display?.let {
                if (it.isStreaming) it.stopStream()
            }
        } catch (_: Exception) {
        }
        display = null
        overlayFilter = null
        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf()
        if (reportStopped) notifyStatus("stopped")
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Live streaming", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else @Suppress("DEPRECATION") Notification.Builder(this)
        val notif = builder
            .setContentTitle("OG Stream Studio")
            .setContentText("You are live")
            .setSmallIcon(applicationInfo.icon)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    override fun onDestroy() {
        try {
            display?.let { if (it.isStreaming) it.stopStream() }
        } catch (_: Exception) {
        }
        display = null
        super.onDestroy()
    }
}
