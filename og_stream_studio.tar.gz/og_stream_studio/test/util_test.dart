import 'package:flutter_test/flutter_test.dart';
import 'package:og_stream_studio/util.dart';

void main() {
  test('snapAxis snaps item centre to canvas centre when close', () {
    // item width 0.4 -> centred start is 0.3
    expect(snapAxis(0.31, 0.4), closeTo(0.3, 1e-9));
    expect(isCentered(snapAxis(0.31, 0.4), 0.4), isTrue);
  });

  test('snapAxis leaves far positions untouched', () {
    expect(snapAxis(0.1, 0.4), 0.1);
  });
}
