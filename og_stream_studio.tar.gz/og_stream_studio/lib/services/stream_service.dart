import 'dart:typed_data';

import 'package:flutter/services.dart';

/// Bridge to the native Android streaming engine (MediaProjection screen
/// capture + RTMP, see native/android/StreamService.kt).
class StreamService {
  StreamService._();

  static const MethodChannel _ch = MethodChannel('og_stream_studio/stream');

  /// Called with: `connecting`, `live`, `stopped`, or `failed: <reason>`.
  static void Function(String status)? onStatus;

  static void init() {
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'status') {
        onStatus?.call(call.arguments as String);
      }
    });
  }

  /// Asks Android for screen-capture permission and starts the RTMP stream.
  static Future<bool> start({
    required String url,
    required int width,
    required int height,
    int fps = 30,
    int bitrate = 3000 * 1000,
  }) async {
    try {
      final ok = await _ch.invokeMethod<bool>('start', {
        'url': url,
        'width': width,
        'height': height,
        'fps': fps,
        'bitrate': bitrate,
      });
      return ok ?? false;
    } on PlatformException catch (e) {
      onStatus?.call('failed: ${e.message}');
      return false;
    } on MissingPluginException {
      onStatus?.call('failed: streaming engine is only available on Android');
      return false;
    }
  }

  static Future<void> stop() async {
    try {
      await _ch.invokeMethod('stop');
    } catch (_) {}
  }

  /// Sends a transparent PNG (chat, text, images...) that is composited over
  /// the captured screen in the outgoing stream.
  static Future<void> setOverlay(Uint8List png) async {
    try {
      await _ch.invokeMethod('overlay', png);
    } catch (_) {}
  }
}
