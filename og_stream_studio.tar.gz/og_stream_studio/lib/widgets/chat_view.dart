import 'package:flutter/material.dart';

import '../models/scene_item.dart';

const chatThemeNames = ['Text', 'Black box', 'Bubble', 'Neon'];

/// Renders the live chat in one of four themes (Text / Black box / Bubble / Neon).
class ChatView extends StatelessWidget {
  const ChatView({
    super.key,
    required this.item,
    required this.messages,
    required this.canvasWidth,
  });

  final SceneItem item;
  final List<ChatMessage> messages;
  final double canvasWidth;

  @override
  Widget build(BuildContext context) {
    final fs = item.chatFont * canvasWidth / 360;
    final recent = messages.length > 14 ? messages.sublist(messages.length - 14) : messages;
    return Opacity(
      opacity: item.chatOpacity.clamp(0.0, 1.0).toDouble(),
      child: ListView(
        reverse: true,
        padding: EdgeInsets.zero,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          for (final m in recent.reversed)
            Padding(
              padding: EdgeInsets.only(bottom: fs * 0.3),
              child: Align(
                alignment: Alignment.centerLeft,
                child: _tile(m, fs),
              ),
            ),
        ],
      ),
    );
  }

  Widget _badge(ChatPlatform p, double fs) => Container(
        width: fs * 1.15,
        height: fs * 1.15,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: p.color, shape: BoxShape.circle),
        child: Text(
          p.letter,
          style: TextStyle(
            color: p == ChatPlatform.kick ? Colors.black : Colors.white,
            fontSize: fs * 0.7,
            fontWeight: FontWeight.w900,
            height: 1,
          ),
        ),
      );

  Widget _tile(ChatMessage m, double fs) {
    final theme = item.chatTheme;
    final nameColor = m.platform.color;
    final textColor = theme == 2 ? Colors.black87 : Colors.white;

    final content = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _badge(m.platform, fs),
        SizedBox(width: fs * 0.4),
        Flexible(
          child: Text.rich(
            TextSpan(children: [
              if (!m.isGift)
                TextSpan(
                  text: '${m.name}  ',
                  style: TextStyle(
                    color: theme == 2 ? nameColor.withAlpha(230) : nameColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              TextSpan(
                text: m.isGift ? '${m.name} ${m.text}' : m.text,
                style: TextStyle(
                  color: m.isGift ? Colors.white : textColor,
                  fontWeight: m.isGift ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ]),
            style: TextStyle(
              fontSize: fs,
              shadows: theme == 0 ? const [Shadow(color: Colors.black, blurRadius: 4)] : null,
            ),
          ),
        ),
      ],
    );

    final pad = EdgeInsets.symmetric(horizontal: fs * 0.6, vertical: fs * 0.25);

    if (m.isGift) {
      return Container(
        padding: pad,
        decoration: BoxDecoration(
          color: const Color(0xFF1565FF),
          borderRadius: BorderRadius.circular(fs * 0.5),
        ),
        child: content,
      );
    }
    switch (theme) {
      case 1:
        return Container(
          padding: pad,
          decoration: BoxDecoration(
            color: const Color(0xCC000000),
            borderRadius: BorderRadius.circular(fs * 0.2),
          ),
          child: content,
        );
      case 2:
        return Container(
          padding: pad,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(fs * 1.2),
          ),
          child: content,
        );
      case 3:
        return Container(
          padding: pad,
          decoration: BoxDecoration(
            color: const Color(0xAA000000),
            borderRadius: BorderRadius.circular(fs * 0.3),
            border: Border.all(color: nameColor, width: 1.5),
            boxShadow: [BoxShadow(color: nameColor.withAlpha(160), blurRadius: 8)],
          ),
          child: content,
        );
      default:
        return Padding(padding: pad, child: content);
    }
  }
}
