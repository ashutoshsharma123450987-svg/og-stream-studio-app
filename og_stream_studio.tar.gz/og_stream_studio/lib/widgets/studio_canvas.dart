import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/scene_item.dart';
import '../state/studio_state.dart';
import '../theme.dart';
import '../util.dart';
import 'item_content.dart';

/// The stream canvas: shows the screen-capture placeholder, all overlay items,
/// and the editing chrome (drag / resize / lock / delete / snap guides).
class StudioCanvas extends StatefulWidget {
  const StudioCanvas({super.key, required this.size, required this.onEdit});

  final Size size;
  final void Function(SceneItem item) onEdit;

  @override
  State<StudioCanvas> createState() => _StudioCanvasState();
}

class _StudioCanvasState extends State<StudioCanvas> {
  bool _guideX = false;
  bool _guideY = false;
  double _rawX = 0;
  double _rawY = 0;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<StudioState>();
    final w = widget.size.width;
    final h = widget.size.height;

    return SizedBox(
      width: w,
      height: h,
      child: ClipRect(
        child: Stack(
          children: [
            // 1. Screen-capture placeholder (the real screen is captured natively).
            Positioned.fill(
              child: ColoredBox(
                color: AppColors.canvas,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.stay_current_landscape_rounded, color: Colors.white70, size: 26),
                      const SizedBox(height: 6),
                      Text(
                        'Screen capture\n(${s.portrait ? 'Portrait' : 'Landscape'})',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // 2. Everything composited over the screen. This is what gets sent
            //    to the encoder as a transparent overlay while live.
            Positioned.fill(
              child: RepaintBoundary(
                key: s.overlayKey,
                child: Stack(
                  children: [
                    for (final it in s.items)
                      Positioned(
                        left: it.x * w,
                        top: it.y * h,
                        width: it.w * w,
                        height: it.h * h,
                        child: ItemContent(item: it, messages: s.messages, canvasWidth: w),
                      ),
                  ],
                ),
              ),
            ),
            // 3. Deselect when tapping empty space.
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onTap: () => s.select(null),
              ),
            ),
            // 4. Per-item gesture + selection chrome.
            for (final it in s.items) _itemLayer(s, it, w, h),
            // 5. Snap guides.
            if (_guideX)
              Positioned(
                left: w / 2 - 0.5,
                top: 0,
                bottom: 0,
                width: 1,
                child: const IgnorePointer(child: ColoredBox(color: AppColors.guide)),
              ),
            if (_guideY)
              Positioned(
                top: h / 2 - 0.5,
                left: 0,
                right: 0,
                height: 1,
                child: const IgnorePointer(child: ColoredBox(color: AppColors.guide)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _itemLayer(StudioState s, SceneItem it, double w, double h) {
    final selected = s.selectedId == it.id;
    return Positioned(
      left: it.x * w,
      top: it.y * h,
      width: it.w * w,
      height: it.h * h,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => s.select(it.id),
        onPanStart: (_) {
          s.select(it.id);
          _rawX = it.x;
          _rawY = it.y;
        },
        onPanUpdate: it.locked
            ? null
            : (d) {
                _rawX += d.delta.dx / w;
                _rawY += d.delta.dy / h;
                final nx = snapAxis(_rawX.clamp(0.0, 1 - it.w).toDouble(), it.w);
                final ny = snapAxis(_rawY.clamp(0.0, 1 - it.h).toDouble(), it.h);
                it.x = nx;
                it.y = ny;
                setState(() {
                  _guideX = isCentered(nx, it.w);
                  _guideY = isCentered(ny, it.h);
                });
                s.changed();
              },
        onPanEnd: (_) => setState(() {
          _guideX = false;
          _guideY = false;
        }),
        child: selected ? _chrome(s, it, w, h) : const SizedBox.expand(),
      ),
    );
  }

  Widget _chrome(StudioState s, SceneItem it, double w, double h) {
    Widget btn(IconData icon, VoidCallback onTap, {Color bg = Colors.black87}) => GestureDetector(
          onTap: onTap,
          child: Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
            child: Icon(icon, size: 15, color: Colors.white),
          ),
        );

    return Container(
      decoration: BoxDecoration(border: Border.all(color: Colors.white, width: 1.5)),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Positioned(
            left: 3,
            top: 3,
            child: btn(it.locked ? Icons.lock_rounded : Icons.lock_open_rounded, () {
              s.toggleLock(it.id);
            }),
          ),
          Positioned(
            right: 3,
            top: 3,
            child: btn(Icons.close_rounded, () => s.removeItem(it.id)),
          ),
          if (it.type == ItemType.chat)
            Positioned(
              top: 3,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(14)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        iconSize: 16,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(minWidth: 28, minHeight: 24),
                        icon: const Icon(Icons.remove, color: Colors.white),
                        onPressed: () {
                          it.chatFont = (it.chatFont - 1).clamp(8, 40).toDouble();
                          s.changed();
                        },
                      ),
                      Text(it.chatFont.round().toString(), style: const TextStyle(fontSize: 12)),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        iconSize: 16,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(minWidth: 28, minHeight: 24),
                        icon: const Icon(Icons.add, color: Colors.white),
                        onPressed: () {
                          it.chatFont = (it.chatFont + 1).clamp(8, 40).toDouble();
                          s.changed();
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: GestureDetector(
                onTap: () => widget.onEdit(it),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(14)),
                  child: const Text('Edit', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                ),
              ),
            ),
          ),
          if (!it.locked)
            Positioned(
              right: 3,
              bottom: 3,
              child: GestureDetector(
                onPanUpdate: (d) {
                  it.w = (it.w + d.delta.dx / w).clamp(0.08, 1.0 - it.x).toDouble();
                  it.h = (it.h + d.delta.dy / h).clamp(0.05, 1.0 - it.y).toDouble();
                  s.changed();
                },
                child: Container(
                  width: 26,
                  height: 26,
                  decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                  child: const Icon(Icons.open_in_full_rounded, size: 15, color: Colors.black),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
