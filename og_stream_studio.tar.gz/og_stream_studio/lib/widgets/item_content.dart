import 'dart:io';

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/scene_item.dart';
import '../models/text_presets.dart';
import 'chat_view.dart';

/// The visual content of a scene item (no editing chrome).
class ItemContent extends StatelessWidget {
  const ItemContent({
    super.key,
    required this.item,
    required this.messages,
    required this.canvasWidth,
  });

  final SceneItem item;
  final List<ChatMessage> messages;
  final double canvasWidth;

  @override
  Widget build(BuildContext context) {
    switch (item.type) {
      case ItemType.chat:
        return ChatView(item: item, messages: messages, canvasWidth: canvasWidth);
      case ItemType.text:
        return _text();
      case ItemType.image:
        final p = item.path;
        if (p == null) return const SizedBox.shrink();
        return Image.file(File(p), fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox.shrink());
      case ItemType.qr:
        return Container(
          color: Colors.white,
          padding: const EdgeInsets.all(4),
          child: QrImageView(
            data: item.text.isEmpty ? 'https://' : item.text,
            backgroundColor: Colors.white,
            padding: EdgeInsets.zero,
          ),
        );
    }
  }

  Widget _text() {
    final preset = textPresets[item.presetIndex.clamp(0, textPresets.length - 1).toInt()];
    var style = preset.style;
    if (item.color != null) style = style.copyWith(color: item.color);
    final hasBox = preset.boxColor != null || preset.borderColor != null;
    final alignment = switch (item.align) {
      TextAlign.left || TextAlign.start => Alignment.centerLeft,
      TextAlign.right || TextAlign.end => Alignment.centerRight,
      _ => Alignment.center,
    };
    return FittedBox(
      fit: BoxFit.contain,
      alignment: alignment,
      child: Container(
        padding: hasBox ? const EdgeInsets.symmetric(horizontal: 14, vertical: 6) : EdgeInsets.zero,
        decoration: hasBox
            ? BoxDecoration(
                color: preset.boxColor,
                borderRadius: BorderRadius.circular(6),
                border: preset.borderColor == null
                    ? null
                    : Border.all(color: preset.borderColor!, width: 2),
              )
            : null,
        child: Text(item.text, style: style, textAlign: item.align),
      ),
    );
  }
}
