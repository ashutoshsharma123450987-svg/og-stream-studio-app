/// Distance (fraction of canvas) within which an item snaps to the centre line.
const double snapThreshold = 0.015;

/// Returns the (possibly snapped) start position of an item so that its centre
/// lands exactly on 0.5 when it is within [snapThreshold] of it.
double snapAxis(double pos, double size) {
  final center = pos + size / 2;
  if ((center - 0.5).abs() < snapThreshold) return 0.5 - size / 2;
  return pos;
}

bool isCentered(double pos, double size) =>
    ((pos + size / 2) - 0.5).abs() < 0.0005;
