import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/studio_state.dart';

void showLayers(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => const _LayersSheet(),
  );
}

class _LayersSheet extends StatelessWidget {
  const _LayersSheet();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<StudioState>();
    final shown = s.items.reversed.toList(); // top layer first
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 8, 4),
              child: Row(
                children: [
                  const Expanded(
                    child: Text('Layers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                ],
              ),
            ),
            Flexible(
              child: ReorderableListView.builder(
                shrinkWrap: true,
                buildDefaultDragHandles: false,
                itemCount: shown.length,
                onReorder: s.reorderDisplay,
                itemBuilder: (ctx, i) {
                  final it = shown[i];
                  return ListTile(
                    key: ValueKey(it.id),
                    selected: s.selectedId == it.id,
                    leading: Icon(it.icon),
                    title: Text(it.label),
                    onTap: () => s.select(it.id),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(it.locked ? Icons.lock_rounded : Icons.lock_open_rounded, size: 20),
                          onPressed: () => s.toggleLock(it.id),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, size: 20),
                          onPressed: () => s.removeItem(it.id),
                        ),
                        ReorderableDragStartListener(
                          index: i,
                          child: const Padding(
                            padding: EdgeInsets.all(8),
                            child: Icon(Icons.drag_handle_rounded),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const ListTile(
              leading: Icon(Icons.stay_current_landscape_rounded),
              title: Text('Screen capture'),
              trailing: Icon(Icons.lock_rounded, size: 20, color: Colors.white38),
            ),
          ],
        ),
      ),
    );
  }
}
