import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../state/studio_state.dart';

const _platforms = <String, String>{
  'YouTube': 'rtmp://a.rtmp.youtube.com/live2',
  'Facebook': 'rtmps://live-api-s.facebook.com:443/rtmp/',
  'Twitch': 'rtmp://live.twitch.tv/app',
  'Custom': '',
};

void showGoLive(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => const _GoLiveSheet(),
  );
}

class _GoLiveSheet extends StatefulWidget {
  const _GoLiveSheet();

  @override
  State<_GoLiveSheet> createState() => _GoLiveSheetState();
}

class _GoLiveSheetState extends State<_GoLiveSheet> {
  final _url = TextEditingController();
  final _key = TextEditingController();
  bool _hide = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      _url.text = p.getString('rtmp_url') ?? _platforms['YouTube']!;
      _key.text = p.getString('stream_key') ?? '';
      if (mounted) setState(() {});
    } catch (_) {
      _url.text = _platforms['YouTube']!;
    }
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final s = context.read<StudioState>();
    final nav = Navigator.of(context);
    final url = _url.text.trim();
    final key = _key.text.trim();
    if (url.isEmpty) return;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('rtmp_url', url);
      await p.setString('stream_key', key);
    } catch (_) {}
    nav.pop();
    await s.goLive(url, key);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Go live', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  for (final e in _platforms.entries)
                    ActionChip(
                      label: Text(e.key),
                      onPressed: () => setState(() => _url.text = e.value),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _url,
                decoration: const InputDecoration(
                  labelText: 'RTMP server URL',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _key,
                obscureText: _hide,
                decoration: InputDecoration(
                  labelText: 'Stream key',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                    onPressed: () => setState(() => _hide = !_hide),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Android will ask permission to capture your screen. '
                'Everything on this canvas (chat, text, images) is added on top of your screen.',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _start,
                  icon: const Icon(Icons.sensors_rounded),
                  label: const Text('Start streaming'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
