import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../models/scene_item.dart';
import '../state/studio_state.dart';
import 'text_sheets.dart';

void showAddSource(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (ctx) => const _AddSourceSheet(),
  );
}

class _AddSourceSheet extends StatelessWidget {
  const _AddSourceSheet();

  @override
  Widget build(BuildContext context) {
    final s = context.read<StudioState>();

    void soon(String what) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$what — coming soon')),
      );
    }

    Widget tile(IconData icon, String label, VoidCallback onTap, {bool ready = true}) => ListTile(
          leading: Icon(icon, color: ready ? Colors.white : Colors.white38),
          title: Text(label, style: TextStyle(color: ready ? Colors.white : Colors.white38)),
          trailing: ready
              ? const Icon(Icons.add_rounded)
              : const Text('Soon', style: TextStyle(color: Colors.white38, fontSize: 12)),
          onTap: onTap,
        );

    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Add source', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              ),
            ),
            tile(Icons.chat_bubble_rounded, 'Chat', () {
              Navigator.pop(context);
              s.addItem(ItemType.chat);
            }),
            tile(Icons.title_rounded, 'Text', () {
              Navigator.pop(context);
              showTextStyles(context);
            }),
            tile(Icons.image_rounded, 'Image', () async {
              final nav = Navigator.of(context);
              final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
              nav.pop();
              if (picked != null) s.addItem(ItemType.image, path: picked.path);
            }),
            tile(Icons.qr_code_2_rounded, 'QR code', () {
              Navigator.pop(context);
              final it = s.addItem(ItemType.qr);
              showTextEditor(context, it);
            }),
            tile(Icons.language_rounded, 'Web', () => soon('Web source'), ready: false),
            tile(Icons.face_rounded, '2D Avatar', () => soon('2D Avatar'), ready: false),
            tile(Icons.view_in_ar_rounded, '3D Avatar', () => soon('3D Avatar'), ready: false),
          ],
        ),
      ),
    );
  }
}
