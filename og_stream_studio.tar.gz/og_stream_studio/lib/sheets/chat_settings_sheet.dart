import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/scene_item.dart';
import '../state/studio_state.dart';
import '../theme.dart';
import '../widgets/chat_view.dart';

void showChatSettings(BuildContext context, SceneItem item) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => _ChatSettings(item: item),
  );
}

class _ChatSettings extends StatefulWidget {
  const _ChatSettings({required this.item});
  final SceneItem item;

  @override
  State<_ChatSettings> createState() => _ChatSettingsState();
}

class _ChatSettingsState extends State<_ChatSettings> {
  @override
  Widget build(BuildContext context) {
    final s = context.read<StudioState>();
    final it = widget.item;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Chat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            const Text('Theme', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.3,
              children: [
                for (var i = 0; i < chatThemeNames.length; i++)
                  InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () {
                      it.chatTheme = i;
                      s.changed();
                      setState(() {});
                    },
                    child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.panel2,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: it.chatTheme == i ? Colors.white : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: Text(chatThemeNames[i], style: const TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Text('Window opacity  ${(it.chatOpacity * 100).round()}%',
                style: const TextStyle(color: Colors.white70)),
            Slider(
              value: it.chatOpacity,
              min: 0.1,
              max: 1,
              onChanged: (v) {
                it.chatOpacity = v;
                s.changed();
                setState(() {});
              },
            ),
            Text('Font size  ${it.chatFont.round()}', style: const TextStyle(color: Colors.white70)),
            Slider(
              value: it.chatFont.clamp(8, 40).toDouble(),
              min: 8,
              max: 40,
              onChanged: (v) {
                it.chatFont = v;
                s.changed();
                setState(() {});
              },
            ),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Save')),
            ),
          ],
        ),
      ),
    );
  }
}
