import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/studio_state.dart';
import '../theme.dart';

void showScreenSettings(BuildContext context, {VoidCallback? onSceneEditing}) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (ctx) => _ScreenSettings(onSceneEditing: onSceneEditing),
  );
}

class _ScreenSettings extends StatelessWidget {
  const _ScreenSettings({this.onSceneEditing});
  final VoidCallback? onSceneEditing;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<StudioState>();
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 8, 4),
            child: Row(
              children: [
                const Expanded(
                  child: Text('Screen settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                ),
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
              ],
            ),
          ),
          ListTile(
            title: const Text('Broadcast aspect ratio'),
            subtitle: s.live ? const Text('Stop the stream to change it') : null,
            trailing: SegmentedButton<bool>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: false, label: Text('16:9')),
                ButtonSegment(value: true, label: Text('9:16')),
              ],
              selected: {s.portrait},
              onSelectionChanged: s.live ? null : (v) => s.setPortrait(v.first),
            ),
          ),
          ListTile(
            title: const Text('Scene editing'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () {
              Navigator.pop(context);
              onSceneEditing?.call();
            },
          ),
          SwitchListTile(
            title: const Text('Screensaver'),
            subtitle: const Text('Show a cover while you are away (UI only for now)'),
            value: s.screensaver,
            activeColor: AppColors.orange,
            onChanged: s.setScreensaver,
          ),
        ],
      ),
    );
  }
}
