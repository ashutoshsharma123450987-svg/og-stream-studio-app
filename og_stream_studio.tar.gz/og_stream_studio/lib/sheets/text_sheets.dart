import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/scene_item.dart';
import '../models/text_presets.dart';
import '../state/studio_state.dart';
import '../theme.dart';

/// Pick a ready-made text style (Title / Social / Caption / Sticker),
/// add it to the canvas and open the editor.
void showTextStyles(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => DefaultTabController(
      length: textCategories.length,
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * 0.5,
        child: Column(
          children: [
            TabBar(
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicatorColor: AppColors.orange,
              labelColor: AppColors.orange,
              tabs: [for (final c in textCategories) Tab(text: c)],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  for (final cat in textCategories)
                    GridView.count(
                      crossAxisCount: 2,
                      padding: const EdgeInsets.all(16),
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.6,
                      children: [
                        for (var i = 0; i < textPresets.length; i++)
                          if (textPresets[i].category == cat)
                            InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: () {
                                final s = ctx.read<StudioState>();
                                Navigator.pop(ctx);
                                final it = s.addItem(ItemType.text, presetIndex: i, text: textPresets[i].name);
                                showTextEditor(context, it);
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppColors.panel2,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                alignment: Alignment.center,
                                child: FittedBox(
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: textPresets[i].boxColor,
                                        border: textPresets[i].borderColor == null
                                            ? null
                                            : Border.all(color: textPresets[i].borderColor!, width: 2),
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(textPresets[i].name, style: textPresets[i].style),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

const _palette = <Color>[
  Colors.white,
  Colors.black,
  Color(0xFFFF5A1F),
  Color(0xFFFFE066),
  Color(0xFF7CFFB2),
  Color(0xFF40C4FF),
  Color(0xFFE040FB),
  Color(0xFFFF1744),
];

/// Edit text (or QR content): content, colour and alignment.
void showTextEditor(BuildContext context, SceneItem item) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => _TextEditor(item: item),
  );
}

class _TextEditor extends StatefulWidget {
  const _TextEditor({required this.item});
  final SceneItem item;

  @override
  State<_TextEditor> createState() => _TextEditorState();
}

class _TextEditorState extends State<_TextEditor> {
  late final TextEditingController _c = TextEditingController(text: widget.item.text);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.read<StudioState>();
    final it = widget.item;
    final isQr = it.type == ItemType.qr;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(isQr ? 'QR code content' : 'Edit text',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              TextField(
                controller: _c,
                autofocus: true,
                maxLines: isQr ? 2 : 3,
                minLines: 1,
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  hintText: isQr ? 'https://your-link' : 'Type here',
                ),
                onChanged: (v) {
                  it.text = v;
                  s.changed();
                },
              ),
              if (!isQr) ...[
                const SizedBox(height: 14),
                Row(
                  children: [
                    for (final c in _palette)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: GestureDetector(
                          onTap: () {
                            it.color = c;
                            s.changed();
                            setState(() {});
                          },
                          child: Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: c,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: it.color == c ? AppColors.orange : Colors.white24,
                                width: it.color == c ? 3 : 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                SegmentedButton<TextAlign>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: TextAlign.left, icon: Icon(Icons.format_align_left)),
                    ButtonSegment(value: TextAlign.center, icon: Icon(Icons.format_align_center)),
                    ButtonSegment(value: TextAlign.right, icon: Icon(Icons.format_align_right)),
                  ],
                  selected: {it.align},
                  onSelectionChanged: (v) {
                    it.align = v.first;
                    s.changed();
                    setState(() {});
                  },
                ),
              ],
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
