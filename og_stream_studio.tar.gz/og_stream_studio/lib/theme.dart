import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0B0B0D);
  static const panel = Color(0xFF1B1B1F);
  static const panel2 = Color(0xFF26262B);
  static const orange = Color(0xFFFF5A1F);
  static const amber = Color(0xFFFFB020);
  static const canvas = Color(0xFF0A1530);
  static const guide = Color(0xFFFFE066);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: base.colorScheme.copyWith(
      primary: AppColors.orange,
      secondary: AppColors.amber,
      surface: AppColors.panel,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: AppColors.panel,
      modalBackgroundColor: AppColors.panel,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
    ),
  );
}
