import 'package:flutter/material.dart';

enum ItemType { chat, text, image, qr }

enum ChatPlatform { youtube, facebook, twitch, kick, other }

extension ChatPlatformX on ChatPlatform {
  Color get color => switch (this) {
        ChatPlatform.youtube => const Color(0xFFFF3D00),
        ChatPlatform.facebook => const Color(0xFF1877F2),
        ChatPlatform.twitch => const Color(0xFF9146FF),
        ChatPlatform.kick => const Color(0xFF53FC18),
        ChatPlatform.other => const Color(0xFF26A69A),
      };

  String get letter => switch (this) {
        ChatPlatform.youtube => 'Y',
        ChatPlatform.facebook => 'f',
        ChatPlatform.twitch => 'T',
        ChatPlatform.kick => 'K',
        ChatPlatform.other => '•',
      };
}

class ChatMessage {
  const ChatMessage({
    required this.name,
    required this.text,
    required this.platform,
    this.isGift = false,
  });

  final String name;
  final String text;
  final ChatPlatform platform;
  final bool isGift;
}

/// One element placed on the stream canvas.
/// Position/size are fractions (0..1) of the canvas, so they survive
/// canvas resizing and aspect-ratio changes.
class SceneItem {
  SceneItem({
    required this.id,
    required this.type,
    this.x = 0.1,
    this.y = 0.1,
    this.w = 0.5,
    this.h = 0.2,
    this.locked = false,
    this.text = 'Text Here',
    this.presetIndex = 0,
    this.color,
    this.align = TextAlign.center,
    this.chatTheme = 0,
    this.chatOpacity = 1.0,
    this.chatFont = 14,
    this.path,
  });

  final String id;
  final ItemType type;
  double x, y, w, h;
  bool locked;

  // text / qr
  String text;
  int presetIndex;
  Color? color;
  TextAlign align;

  // chat
  int chatTheme;
  double chatOpacity;
  double chatFont;

  // image
  String? path;

  String get label => switch (type) {
        ItemType.chat => 'Chat',
        ItemType.text => 'Text',
        ItemType.image => 'Image',
        ItemType.qr => 'QR code',
      };

  IconData get icon => switch (type) {
        ItemType.chat => Icons.chat_bubble_rounded,
        ItemType.text => Icons.title_rounded,
        ItemType.image => Icons.image_rounded,
        ItemType.qr => Icons.qr_code_2_rounded,
      };
}
