import 'package:flutter/material.dart';

class TextPreset {
  const TextPreset(
    this.name,
    this.category,
    this.style, {
    this.boxColor,
    this.borderColor,
  });

  final String name;
  final String category;
  final TextStyle style;
  final Color? boxColor;
  final Color? borderColor;
}

const textCategories = ['TITLE', 'SOCIAL', 'CAPTION', 'STICKER'];

const textPresets = <TextPreset>[
  // TITLE
  TextPreset('Text Here', 'TITLE',
      TextStyle(fontSize: 40, fontWeight: FontWeight.w800, color: Colors.white)),
  TextPreset('Outline Box', 'TITLE',
      TextStyle(fontSize: 36, fontWeight: FontWeight.w700, color: Colors.white),
      borderColor: Colors.white),
  TextPreset(
      'Neon',
      'TITLE',
      TextStyle(fontSize: 38, fontWeight: FontWeight.w800, color: Colors.white, shadows: [
        Shadow(color: Color(0xFFFF5A1F), blurRadius: 14),
        Shadow(color: Color(0xFFFF5A1F), blurRadius: 28),
      ])),
  TextPreset('Serif', 'TITLE',
      TextStyle(fontSize: 38, fontFamily: 'serif', fontWeight: FontWeight.w700, color: Colors.white)),
  // SOCIAL
  TextPreset('Follow', 'SOCIAL',
      TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white),
      boxColor: Color(0xFFE53935)),
  TextPreset('@handle', 'SOCIAL',
      TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Colors.black),
      boxColor: Colors.white),
  TextPreset('Subscribe', 'SOCIAL',
      TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white),
      boxColor: Color(0xFFFF0000), borderColor: Colors.white),
  // CAPTION
  TextPreset('Caption', 'CAPTION',
      TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Colors.white),
      boxColor: Color(0xB3000000)),
  TextPreset('Yellow Sub', 'CAPTION',
      TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Color(0xFFFFE066), shadows: [
        Shadow(color: Colors.black, blurRadius: 4),
      ])),
  TextPreset('Mono', 'CAPTION',
      TextStyle(fontSize: 24, fontFamily: 'monospace', color: Color(0xFF7CFFB2)),
      boxColor: Color(0xCC000000)),
  // STICKER
  TextPreset('LIVE', 'STICKER',
      TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Colors.white),
      boxColor: Color(0xFFD50000)),
  TextPreset('NEW', 'STICKER',
      TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Colors.black),
      boxColor: Color(0xFFFFD600)),
  TextPreset('GG', 'STICKER',
      TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Colors.white),
      boxColor: Color(0xFF7C4DFF)),
];
