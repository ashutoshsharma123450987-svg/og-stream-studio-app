import 'dart:async';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/scene_item.dart';
import '../services/stream_service.dart';

class StudioState extends ChangeNotifier {
  StudioState() {
    items.add(SceneItem(
      id: _newId(),
      type: ItemType.chat,
      x: 0.04,
      y: 0.62,
      w: 0.92,
      h: 0.3,
    ));
    StreamService.onStatus = _onStatus;
    _chatTimer = Timer.periodic(const Duration(milliseconds: 2200), (_) => _addDemoMessage());
    for (var i = 0; i < 5; i++) {
      _addDemoMessage(notify: false);
    }
  }

  // ---- scene -------------------------------------------------------------
  /// Index 0 is the bottom-most layer; the screen capture is always below all.
  final List<SceneItem> items = [];
  String? selectedId;
  bool portrait = true;
  String mode = 'Screen';
  bool screensaver = false;

  /// Boundary around everything that is composited over the screen capture.
  final GlobalKey overlayKey = GlobalKey();

  int _idCounter = 0;
  String _newId() => 'item_${_idCounter++}';

  SceneItem? get selected {
    for (final i in items) {
      if (i.id == selectedId) return i;
    }
    return null;
  }

  int get streamWidth => portrait ? 720 : 1280;
  int get streamHeight => portrait ? 1280 : 720;

  void setMode(String m) {
    mode = m;
    notifyListeners();
  }

  void setScreensaver(bool v) {
    screensaver = v;
    notifyListeners();
  }

  void setPortrait(bool v) {
    if (live) return;
    portrait = v;
    notifyListeners();
  }

  SceneItem addItem(ItemType type, {int presetIndex = 0, String? path, String? text}) {
    final item = switch (type) {
      ItemType.chat => SceneItem(id: _newId(), type: type, x: 0.04, y: 0.62, w: 0.92, h: 0.3),
      ItemType.text => SceneItem(
          id: _newId(),
          type: type,
          x: 0.15,
          y: 0.08,
          w: 0.7,
          h: 0.1,
          presetIndex: presetIndex,
          text: text ?? 'Text Here',
        ),
      ItemType.image => SceneItem(id: _newId(), type: type, x: 0.7, y: 0.05, w: 0.25, h: 0.14, path: path),
      ItemType.qr => SceneItem(
          id: _newId(),
          type: type,
          x: 0.7,
          y: 0.4,
          w: 0.24,
          h: 0.14,
          text: text ?? 'https://example.com',
        ),
    };
    items.add(item);
    selectedId = item.id;
    notifyListeners();
    return item;
  }

  void select(String? id) {
    selectedId = id;
    notifyListeners();
  }

  void removeItem(String id) {
    items.removeWhere((i) => i.id == id);
    if (selectedId == id) selectedId = null;
    notifyListeners();
  }

  void toggleLock(String id) {
    for (final i in items) {
      if (i.id == id) i.locked = !i.locked;
    }
    notifyListeners();
  }

  /// [oldDisplay]/[newDisplay] are indices in the layers panel (top layer first).
  void reorderDisplay(int oldDisplay, int newDisplay) {
    if (newDisplay > oldDisplay) newDisplay -= 1;
    final n = items.length;
    final oldIdx = n - 1 - oldDisplay;
    final newIdx = n - 1 - newDisplay;
    final item = items.removeAt(oldIdx);
    items.insert(newIdx, item);
    notifyListeners();
  }

  /// Call after mutating an item in place.
  void changed() => notifyListeners();

  // ---- demo chat ---------------------------------------------------------
  // TODO: replace with real YouTube / Facebook / Twitch / Kick chat sources.
  final List<ChatMessage> messages = [];
  final _rng = Random();
  Timer? _chatTimer;

  static const _names = ['Amy', 'Eddie', 'Jay', 'Min', 'Sun', 'Zina', 'Ann', 'Eva', 'Lisa', 'Eden'];
  static const _texts = [
    'Hello!',
    "I can't wait!",
    'So fun to watch 😍',
    'Awesome stream!',
    'LOL!!!',
    "You're awesome 💕",
    'Yo',
    'Hey!',
    'Finally!',
    "I'm so hooked on you",
  ];

  void _addDemoMessage({bool notify = true}) {
    final gift = _rng.nextInt(12) == 0;
    messages.add(ChatMessage(
      name: _names[_rng.nextInt(_names.length)],
      text: gift ? 'gifted 10 star balloons' : _texts[_rng.nextInt(_texts.length)],
      platform: ChatPlatform.values[_rng.nextInt(ChatPlatform.values.length)],
      isGift: gift,
    ));
    if (messages.length > 40) messages.removeAt(0);
    if (notify) notifyListeners();
  }

  // ---- streaming ---------------------------------------------------------
  bool live = false;
  String status = 'Offline';
  Timer? _overlayTimer;

  void _onStatus(String s) {
    status = s;
    if (s == 'connecting' || s == 'live') {
      live = true;
      _startOverlayPush();
    } else {
      live = false;
      _overlayTimer?.cancel();
      _overlayTimer = null;
    }
    notifyListeners();
  }

  Future<void> goLive(String url, String key) async {
    await [Permission.microphone, Permission.notification].request();
    final full = key.isEmpty ? url : '${url.endsWith('/') ? url : '$url/'}$key';
    status = 'connecting';
    live = true;
    notifyListeners();
    final ok = await StreamService.start(
      url: full,
      width: streamWidth,
      height: streamHeight,
    );
    if (!ok) {
      live = false;
      if (!status.startsWith('failed')) status = 'failed: could not start';
      notifyListeners();
    }
  }

  Future<void> stopLive() async {
    await StreamService.stop();
  }

  void _startOverlayPush() {
    _overlayTimer?.cancel();
    _pushOverlay();
    _overlayTimer = Timer.periodic(const Duration(milliseconds: 900), (_) => _pushOverlay());
  }

  Future<void> _pushOverlay() async {
    try {
      final ro = overlayKey.currentContext?.findRenderObject();
      if (ro is! RenderRepaintBoundary || !ro.hasSize || ro.size.width == 0) return;
      final ratio = streamWidth / ro.size.width;
      final image = await ro.toImage(pixelRatio: ratio);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data != null) {
        await StreamService.setOverlay(data.buffer.asUint8List());
      }
    } catch (_) {
      // A frame that fails to capture is simply skipped.
    }
  }

  @override
  void dispose() {
    _chatTimer?.cancel();
    _overlayTimer?.cancel();
    super.dispose();
  }
}
