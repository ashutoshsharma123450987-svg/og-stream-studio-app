import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../sheets/screen_settings_sheet.dart';
import '../state/studio_state.dart';
import '../theme.dart';
import 'editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _openEditor(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const EditorScreen()));
  }

  void _soon(BuildContext context, String what) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('$what — coming soon')));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<StudioState>();
    final aspect = s.portrait ? 9 / 16 : 16 / 9;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset('assets/logo.png', width: 38, height: 38),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'OG STREAM STUDIO',
                    style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 15),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    GestureDetector(
                      onTap: () => _openEditor(context),
                      child: SizedBox(
                        width: s.portrait ? 120 : 220,
                        child: AspectRatio(
                          aspectRatio: aspect,
                          child: Stack(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  color: AppColors.canvas,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.white70, width: 2),
                                ),
                                alignment: Alignment.center,
                                child: Text(s.portrait ? '9:16' : '16:9'),
                              ),
                              Positioned(
                                right: 4,
                                top: 4,
                                child: GestureDetector(
                                  onTap: () => showScreenSettings(
                                    context,
                                    onSceneEditing: () => _openEditor(context),
                                  ),
                                  child: Container(
                                    padding: const EdgeInsets.all(3),
                                    decoration: const BoxDecoration(color: AppColors.amber, shape: BoxShape.circle),
                                    child: const Icon(Icons.settings_rounded, size: 14, color: Colors.black),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Video aspect ratio: ${s.portrait ? '9:16' : '16:9'}\n'
                      'Capture orientation: ${s.portrait ? 'Portrait' : 'Landscape'}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white54, fontSize: 12),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('Screensaver', style: TextStyle(fontSize: 13)),
                        Switch(
                          value: s.screensaver,
                          activeColor: AppColors.orange,
                          onChanged: s.setScreensaver,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SegmentedButton<String>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 'Screen', label: Text('Screen')),
                ButtonSegment(value: 'Camera', label: Text('Camera')),
                ButtonSegment(value: 'VTuber', label: Text('VTuber')),
              ],
              selected: {s.mode},
              onSelectionChanged: (v) {
                final m = v.first;
                if (m != 'Screen') {
                  _soon(context, '$m mode');
                  return;
                }
                s.setMode(m);
              },
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: 200,
              height: 52,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                onPressed: () => _openEditor(context),
                child: const Text('Ready', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (final t in ['CONNECT', 'LIVE', 'VIDEO', 'PHOTO'])
                  GestureDetector(
                    onTap: t == 'LIVE' ? null : () => _soon(context, t),
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        t,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: t == 'LIVE' ? Colors.white : Colors.white38,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }
}
