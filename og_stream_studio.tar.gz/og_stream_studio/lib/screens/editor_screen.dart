import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../models/scene_item.dart';
import '../sheets/add_source_sheet.dart';
import '../sheets/chat_settings_sheet.dart';
import '../sheets/go_live_sheet.dart';
import '../sheets/layers_sheet.dart';
import '../sheets/text_sheets.dart';
import '../state/studio_state.dart';
import '../theme.dart';
import '../widgets/studio_canvas.dart';

class EditorScreen extends StatelessWidget {
  const EditorScreen({super.key});

  Future<void> _edit(BuildContext context, SceneItem it) async {
    final s = context.read<StudioState>();
    switch (it.type) {
      case ItemType.chat:
        showChatSettings(context, it);
      case ItemType.text:
      case ItemType.qr:
        showTextEditor(context, it);
      case ItemType.image:
        final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
        if (picked != null) {
          it.path = picked.path;
          s.changed();
        }
    }
  }

  void _help(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('How it works'),
        content: const Text(
          '• Tap + to add Chat, Text, Image or QR.\n'
          '• Drag to move, use the corner handle to resize. Yellow lines show the centre.\n'
          '• Layers: reorder, lock or delete items.\n'
          '• Go Live: enter your RTMP URL + stream key. Your screen is captured, '
          'and everything on this canvas is added on top.',
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<StudioState>();
    final aspect = s.portrait ? 9 / 16 : 16 / 9;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_rounded),
                    onPressed: () => Navigator.maybePop(context),
                  ),
                  IconButton(
                    icon: const Icon(Icons.help_outline_rounded),
                    onPressed: () => _help(context),
                  ),
                  const Spacer(),
                  _StatusChip(status: s.status, live: s.live),
                  const SizedBox(width: 8),
                  s.live
                      ? FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
                          onPressed: s.stopLive,
                          icon: const Icon(Icons.stop_rounded),
                          label: const Text('Stop'),
                        )
                      : FilledButton.icon(
                          onPressed: () => showGoLive(context),
                          icon: const Icon(Icons.sensors_rounded),
                          label: const Text('Go Live'),
                        ),
                ],
              ),
            ),
            Expanded(
              child: Stack(
                children: [
                  Center(
                    child: LayoutBuilder(
                      builder: (ctx, c) {
                        var w = c.maxWidth - 72; // leave room for the side toolbar
                        var h = w / aspect;
                        if (h > c.maxHeight) {
                          h = c.maxHeight;
                          w = h * aspect;
                        }
                        return Padding(
                          padding: const EdgeInsets.only(right: 56),
                          child: DecoratedBox(
                            decoration: BoxDecoration(border: Border.all(color: Colors.white24)),
                            child: StudioCanvas(
                              size: Size(w, h),
                              onEdit: (it) => _edit(context, it),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Positioned(
                    right: 8,
                    top: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.panel,
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: Column(
                        children: [
                          IconButton(
                            tooltip: 'Add source',
                            icon: const Icon(Icons.add_rounded),
                            onPressed: () => showAddSource(context),
                          ),
                          IconButton(
                            tooltip: 'Layers',
                            icon: const Icon(Icons.layers_rounded),
                            onPressed: () => showLayers(context),
                          ),
                          IconButton(
                            tooltip: s.portrait ? 'Switch to 16:9' : 'Switch to 9:16',
                            icon: Icon(s.portrait
                                ? Icons.stay_current_landscape_rounded
                                : Icons.stay_current_portrait_rounded),
                            onPressed: s.live ? null : () => s.setPortrait(!s.portrait),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.status, required this.live});
  final String status;
  final bool live;

  @override
  Widget build(BuildContext context) {
    final failed = status.startsWith('failed');
    final color = live ? Colors.redAccent : (failed ? Colors.amber : Colors.white38);
    final label = failed ? 'Error' : (status == 'live' ? 'LIVE' : status == 'connecting' ? 'Connecting…' : 'Offline');
    return Tooltip(
      message: failed ? status : label,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          border: Border.all(color: color),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.circle, size: 8, color: color),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}
