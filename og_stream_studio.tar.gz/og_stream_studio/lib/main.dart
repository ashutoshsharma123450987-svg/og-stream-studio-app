import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/home_screen.dart';
import 'services/stream_service.dart';
import 'state/studio_state.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  StreamService.init();
  runApp(
    ChangeNotifierProvider(
      create: (_) => StudioState(),
      child: const OgStreamStudioApp(),
    ),
  );
}

class OgStreamStudioApp extends StatelessWidget {
  const OgStreamStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OG Stream Studio',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
