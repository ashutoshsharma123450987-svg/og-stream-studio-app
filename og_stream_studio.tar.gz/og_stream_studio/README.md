<p align="center"><img src="assets/logo.png" width="180" alt="OG Stream Studio"></p>

# OG STREAM STUDIO
**Create • Stream • Share** — a mobile live-streaming studio built with Flutter.

## What works in v0.1 (MVP)

| Feature | Status |
|---|---|
| Home: Screen mode, 16:9 / 9:16 aspect ratio, Ready button | ✅ |
| Scene editor canvas: drag, resize, lock, delete, centre snap guides | ✅ |
| Add source: **Chat, Text, Image, QR code** | ✅ |
| Layers panel: reorder, lock, delete | ✅ |
| Chat overlay: 4 themes (Text / Black box / Bubble / Neon), opacity, font size, gift alerts | ✅ (demo messages) |
| Text: 13 ready styles (Title / Social / Caption / Sticker), colour, alignment | ✅ |
| Screen capture + RTMP streaming (YouTube / Facebook / Twitch / custom) with overlays composited on top | ✅ Android, needs device testing |
| Camera mode, VTuber mode, Web source, 2D/3D avatar | 🔜 |
| Real chat from YouTube / Facebook / Twitch / Kick (currently demo messages) | 🔜 |
| Video recording, photo, screensaver cover | 🔜 |

## How the streaming works
Flutter draws the editor. When you go live, Android's MediaProjection captures the
screen and [RootEncoder](https://github.com/pedroSG94/RootEncoder) encodes + sends it over RTMP.
Everything on the canvas except the screen placeholder (chat, text, images, QR) is
rendered to a transparent PNG about once a second and composited over the captured
screen in the outgoing stream. Native code lives in `native/android/`.

Note: for a 16:9 stream, rotate the phone to landscape (e.g. in a game) so the
captured screen matches the stream shape; otherwise the picture is stretched.

## Build

The `android/` folder is generated, so the repo stays small.

```bash
# needs Flutter (stable) + Android SDK + JDK 17
bash scripts/setup_android.sh     # flutter create + native code + icons
flutter run                       # on a connected Android phone
flutter build apk --release
```

Pushing to GitHub also builds an APK automatically (`.github/workflows/build.yml`);
download it from the run's **Artifacts**.

## Project layout
```
lib/
  main.dart, theme.dart, util.dart
  models/    scene items, text presets
  state/     StudioState (scene, chat, live status, overlay capture)
  services/  MethodChannel bridge to native streaming
  screens/   home, editor
  sheets/    add source, layers, chat settings, text, go-live, screen settings
  widgets/   canvas, chat view, item renderer
native/android/   MainActivity.kt + StreamService.kt (MediaProjection + RTMP)
scripts/          setup_android.sh, patch_android.py
```

## Roadmap
1. Real chat connectors (YouTube Live Chat API first)
2. Camera source + picture-in-picture
3. Local recording, photo capture
4. Web source (WebView overlay), avatars
5. Save/load scenes, multi-stream
