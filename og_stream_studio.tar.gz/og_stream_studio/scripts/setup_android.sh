#!/usr/bin/env bash
# Generates the android/ project and applies OG Stream Studio's native streaming code.
# Needs Flutter on PATH. Safe to re-run.
set -euo pipefail
cd "$(dirname "$0")/.."

flutter create --platforms=android --org com.ogstudio --project-name og_stream_studio .
python3 scripts/patch_android.py
flutter pub get
dart run flutter_launcher_icons
echo "Done. Run: flutter run   or   flutter build apk --release"
