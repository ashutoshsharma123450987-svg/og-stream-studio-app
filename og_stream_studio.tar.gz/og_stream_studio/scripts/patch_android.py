#!/usr/bin/env python3
"""Patches the Flutter-generated android/ folder for OG Stream Studio.

Run after `flutter create --platforms=android --org com.ogstudio .`
(see scripts/setup_android.sh). Idempotent.
"""
import pathlib
import re
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
ANDROID = ROOT / "android"
PKG_DIR = ANDROID / "app/src/main/kotlin/com/ogstudio/og_stream_studio"
ROOTENCODER = "com.github.pedroSG94.RootEncoder:library:2.5.5"


def die(msg):
    print("patch_android: " + msg, file=sys.stderr)
    sys.exit(1)


# 1. Kotlin sources ---------------------------------------------------------
if not ANDROID.exists():
    die("android/ not found - run flutter create first")
PKG_DIR.mkdir(parents=True, exist_ok=True)
for f in ("MainActivity.kt", "StreamService.kt"):
    shutil.copy(ROOT / "native/android" / f, PKG_DIR / f)

# 2. Manifest ---------------------------------------------------------------
mf = ANDROID / "app/src/main/AndroidManifest.xml"
m = mf.read_text()
perms = [
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.WAKE_LOCK",
]
add = "".join(
    f'    <uses-permission android:name="{p}"/>\n'
    for p in perms
    if f'"{p}"' not in m
)
if add:
    m = m.replace("<application", add + "    <application", 1)
m = re.sub(r'android:label="[^"]*"', 'android:label="OG Stream Studio"', m, count=1)
if "StreamService" not in m:
    svc = (
        '        <service android:name=".StreamService"\n'
        '            android:exported="false"\n'
        '            android:foregroundServiceType="mediaProjection"/>\n'
    )
    m = m.replace("</application>", svc + "    </application>", 1)
mf.write_text(m)

# 3. Gradle: JitPack repo + RootEncoder -------------------------------------
# project-level repositories
patched_repo = False
for name in ("build.gradle.kts", "build.gradle"):
    p = ANDROID / name
    if not p.exists():
        continue
    t = p.read_text()
    if "jitpack.io" not in t and "mavenCentral()" in t:
        if name.endswith(".kts"):
            t = t.replace("mavenCentral()", 'mavenCentral()\n        maven { url = uri("https://jitpack.io") }', 1)
        else:
            t = t.replace("mavenCentral()", "mavenCentral()\n        maven { url 'https://jitpack.io' }", 1)
        p.write_text(t)
    patched_repo = patched_repo or "jitpack.io" in t

# newer Flutter templates use dependencyResolutionManagement in settings.gradle
for name in ("settings.gradle.kts", "settings.gradle"):
    p = ANDROID / name
    if p.exists():
        t = p.read_text()
        if "dependencyResolutionManagement" in t and "jitpack.io" not in t:
            die("settings.gradle uses dependencyResolutionManagement; add jitpack there manually")

if not patched_repo:
    die("could not add JitPack repository")

# app-level dependency
for name in ("build.gradle.kts", "build.gradle"):
    p = ANDROID / "app" / name
    if not p.exists():
        continue
    t = p.read_text()
    if "RootEncoder" not in t:
        if name.endswith(".kts"):
            t += f'\n\ndependencies {{\n    implementation("{ROOTENCODER}")\n}}\n'
        else:
            t += f"\n\ndependencies {{\n    implementation '{ROOTENCODER}'\n}}\n"
        p.write_text(t)
    break
else:
    die("app/build.gradle not found")

print("android/ patched OK")
